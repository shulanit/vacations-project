import React from 'react';
import './App.css';
import { BrowserRouter , Route } from "react-router-dom";
import Login from './components/login/Login';
import Registration from './components/registration/Registration';
import Main from './components/main/Main';
import MainAdmin from './components/admin/main-admin/Main-Admin';
import AddVacation from './components/admin/Add-Vacation';


function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Route path="/" exact component={Login}/>
        <Route path="/registration" component={Registration}/>
        <Route path="/main" component={Main}/>
        <Route path="/main-admin" component={MainAdmin}/>
        <Route path="/add" component={AddVacation}/> 
      </BrowserRouter>
    </div>
  );

  
}


export default App;
