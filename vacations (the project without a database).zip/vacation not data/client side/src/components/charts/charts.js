import React from 'react';
import { Bar as BarChart } from 'react-chartjs-2';

class Chart extends React.Component {
  constructor() {
    super();
    const data = {
      labels: [],//name/id vacation
      datasets: [{
        label: "FOLLOWERS PER VACATION",
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(153, 102, 255, 0.2)',
          'rgba(255, 159, 64, 0.2)'
        ],
        borderColor: [
          'rgba(255,99,132,1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
          'rgba(255, 159, 64, 1)'
        ],
        borderWidth: 1,
        data: [],//count followers after vacation
      }]
    };
    const options = {
      scales: {
        xAxes: [{
          stacked: true
        }],
        yAxes: [{
          stacked: true
        }]
      }
    };
    this.state = {
      chartData: data,
      chartOptions: options,
    };
  }

  componentDidMount = () => {
    console.log(this.props.data);



    let temp = [];
    let temp2 = [];
    for (let i = 0; i < this.props.data.length; i++) {
      if(this.props.data[i].count_followers > 0){
        temp.push(this.props.data[i].id);//id = vacation_id
        temp2.push(this.props.data[i].count_followers);
      }
    }

    

    this.setState(Object.assign(
      this.state.chartData.labels, { ...temp }//... = זה לא מצביע על מיקום אלא מעתיק אותו מאיפה שהוא
    ));
    this.setState(Object.assign(
      this.state.chartData.datasets[0].data, { ...temp2 }
    ));

  }
  render() {
    const { chartData, chartOptions } = this.state;
    return (
      <div>
        <BarChart data={chartData} options={chartOptions} />
      </div>
    )
  }
}

export default Chart;