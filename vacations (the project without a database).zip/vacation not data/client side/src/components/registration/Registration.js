import React,{Component} from 'react';
import axios from 'axios';
import './Registration.css';

class Registration extends Component{
    state = {
        name_reg:"",
        lastname_reg:"",
        username_reg:"",
        pass_reg:"",
        error_message:"",
        show_error_message:"",
        link_in:false

    }

    render(){
        return(
            <div className='container'>
                <div className='registration'>
                <div className='row'>
                <div className='col-md-12'>
                    <form>
                        <div className='form'>
                        <h3>Registration</h3>
                        <div className="form-group">
                        <label>Name:</label><br/>
                        <input type='text' className="form-control col-md-4" id='name_reg' onChange={this.handleChange} value={this.state.name_reg}/>
                        </div>
                        <div className="form-group">
                        <label>Last Name:</label><br/>
                        <input type='text' className="form-control col-md-4" id='lastname_reg' onChange={this.handleChange} value={this.state.lastname_reg}/>
                        </div>
                        <div className="form-group">
                        <label>User Name:</label><br/>
                        <input type='text' className="form-control col-md-4" id='username_reg' onChange={this.handleChange} value={this.state.username_reg}/>
                        </div>
                        <div className="form-group">
                        <label>Password:</label><br/>
                        <input type='password' className="form-control col-md-4" id='pass_reg' onChange={this.handleChange} value={this.state.pass_reg}/>
                        </div>

                        <div className='btn btn-danger' onClick={this.createUser.bind(this)}>create</div>
                        </div>
                    </form>
                    <div className="alert alert-danger" id="messege" role="alert">
                        {this.state.error_message}
                    </div>
                    
                </div>
                </div>
                </div>
            </div>
        )
    }

    handleChange = event => {
        this.setState({
            [event.target.id]: event.target.value
        });
    }

    
    createUser(){
        let user = {
            name:this.state.name_reg,
            lastname:this.state.lastname_reg,
            username:this.state.username_reg,
            password:this.state.pass_reg
        }
        axios.put('/registration/create',{user:user})
        .then( (response) => {
            console.log(response);    
          if( response.data.response_text === "user created in success!" ){ 
            console.log(response.data.response_text);  

            this.state.error_message=response.data.response_text;
            this.state.show_error_message = true;
            this.setState({});
            this.props.history.push('/');
            }else{
              this.state.error_message=response.data.response_text;
              this.state.show_error_message = true;
              this.setState({});
            }
        })
        .catch(function(error){
          console.log(error);
          //Perform action based on error
      });
    

    }
    
}

export default Registration;