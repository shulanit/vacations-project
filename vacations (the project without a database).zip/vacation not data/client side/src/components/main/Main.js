import React,{Component} from 'react';
import axios from 'axios';
import './Main.css';

class Main extends Component{
    constructor(props){
        super(props);
        this.state = {
            user_id:0,
            username:"",
            vacations:[],
            vacations_others:[]
        };

      }
    
    state = {
        vacation_id:0,
        
    }

    componentDidMount(){
        // this.setState(this.state.username);
        this.getData();
        this.interval = setInterval(() => {
            this.getData();
          },3000);   
    }

    componentWillUnmount() {
        clearInterval(this.interval);
    }

    getData(){
        //console.log("this get data");
        this.getVacations();
        this.getVacationsOthers();
    }

    render(){
        return(
            <div className='main_vacations'>
            <div className='container'>
                <div className="col-md-12">
                <header>hello {this.state.username}</header>
                <button type="button" className="btn btn-danger" onClick={this.logout.bind(this)}>Logout</button>
                </div>
                <br/>
                <h2 id="title">vacations</h2>
                    <h4 id="h_in_follow">vacations in follow up</h4><br/>
                        <div className="row">
                            {this.state.vacations.map((vacation) =>
                                <div className="col-md-4" key={vacation.id}>
                                    <div className="m-2">
                                    <div className="card item">
                                        <i className="far fa-thumbs-up unlike" onClick={this._like.bind(this,vacation.id)}></i>
                                        <img className="card-img-top" src={vacation.image} alt="Card image cap"/>  
                                        <div className="card-title">
                                            <div className="card-text">{vacation.destination}</div>
                                        </div>
                                        <div className="card-body">
                                            <div className="card-text">{vacation.description}</div>
                                            <div className="card-date">start: {vacation.dep}</div>
                                            <div className="card-date">end: {vacation.endd}</div>
                                        </div>
                                        <div className="card-footer">
                                            <div className="card-text">{vacation.price} $ </div>
                                        </div>
                                    </div>
                                    </div>
                               
                                </div>
                                
                                ) 
                            }
                            </div>
                        
                    <h4 id="h_others">vacation others</h4>
                    <div className="row">
                            {this.state.vacations_others.map((vacation) =>
                                <div className="col-md-4" key={vacation.id}>
                                    <div className="m-2">
                                    <div className="card item">
                                        <i className="far fa-thumbs-up like_unlike" onClick={this._like.bind(this,vacation.id)}></i>
                                        <img className="card-img-top" src={vacation.image} alt="Card image cap" />
                                        <div className="card-title">
                                            <div className="card-text">{vacation.destination}</div>
                                        </div>
                                        <div className="card-body">
                                            <div className="card-text">{vacation.description}</div>
                                            <div className="card-date">start: {vacation.dep}</div>
                                            <div className="card-date">end: {vacation.endd}</div>
                                        </div>
                                        <div className="card-footer">
                                            <div className="card-text">{vacation.price} $ </div>
                                        </div>
                                    </div>
                                    </div>
                               
                                </div>
                                
                                ) 
                            }
                        </div>   
            </div>{/*container*/}
            </div>//main_vacations
        )
    }

    handleChange = event => {
        this.setState({
            [event.target.id]: event.target.value
        });
    }

    getVacations(){
        axios.get('/vacations',{})
        .then( (response) => {
          if( response.data.data.length ){
            this.state.vacations = [];
            this.setState({vacations:response.data.data});   
            }else{  
            this.state.error_message=response.data.response_text;
            this.state.show_error_message = true;
            this.setState({});
            }
        })
        .catch(function(error){
            console.log(error);
            //Perform action based on error
        });
    }

    getVacationsOthers(){
        axios.get('/vacations/others',{})
        .then( (response) => {
            var data_all_vac=response.data.data;//all vacations
            if(response.data.data){
                this.vacations=[];
                this.vacations_others=[];
                for(let i=0; i<data_all_vac.length;i++){
                    for(let j=0;j<this.state.vacations.length;j++){
                        if(data_all_vac[i].id === this.state.vacations[j].id){
                            data_all_vac.splice(i, 1);    
                        }
                    }
                }
                this.setState({vacations_others:data_all_vac});
            }
            else{  
              this.state.error_message=response.data.response_text;
              this.state.show_error_message = true;
              this.setState({});
            }
        })
        .catch(function(error){
            console.log(error);
            //Perform action based on error
        });
    }

    _like(vacation_id){
        axios.put('/users/setlike',{id:vacation_id})
        .then( (response) => {
            console.log(response);
                if( response ){
                    console.log(response);
                    this.getVacations();
                }
                else{
                    this.state.error_message=response.data.response_text;
                    this.state.show_error_message = true;
                    this.setState({});
                }
            })
            .catch(function(error){
            console.log(error);
            //Perform action based on error
        });
    }
        
      logout() {
        axios.post('/users/logout')
        .then( (response) => {
            this.props.history.push('/');
        })
        .catch(function(error){
            console.log(error);
      })
    }
}

export default Main;