import React,{Component} from 'react';
import axios from 'axios';
import { Link } from "react-router-dom";
import './Login.css';


class Login extends Component{
    constructor(props) {
       
        super(props);
        this.state = {
            user_id:0,
            username:"",//Administrator
            password:""//123456
        }; 
        
        this.checkSession();
    }


    render(){
        return(
            <div className='body'>
                <div className="flex-container">
                    <div className="d-flex justify-content-center h-100">
                        <div className="card">
                            <div className="card-header">
                                <h3>Sign In</h3>
                                <div className="d-flex justify-content-end social_icon">
                                    <span><i className="fab fa-facebook-square"></i></span>
                                </div>
                            </div>
                            <div className="card-body">
                                <form>
                                    <div className="input-group form-group">
                                        <div className="input-group-prepend">
                                            <span className="input-group-text"><i className="fas fa-user"></i></span>
                                        </div>
                                        <input type="text" className="form-control" id='username' placeholder="username" onChange={this.handleChange} value={this.state.username}/>   
                                    </div>
                                    <div className="input-group form-group">
                                        <div className="input-group-prepend">
                                            <span className="input-group-text"><i className="fas fa-key"></i></span>
                                        </div>
                                        <input type="password" className="form-control" id='password' placeholder="password" onChange={this.handleChange} value={this.state.password}/>
                                    </div>
                                    <div className="row align-items-center remember">
                                        <input type="checkbox" id='remember'/>Remember Me
                                    </div>
                                    <div className="form-group">
                                        <input type="button" value="Login" className="btn float-right login_btn" onClick={this.login.bind(this)}/>

                                    </div>
                                </form>
                            </div>
                            <div className="card-footer">
                                <div className="d-flex justify-content-center links">
                                    Don't have an account?<Link to={'/registration'}>registration</Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>   
        )
        
    }
        
    handleChange = (event) => {
        this.setState({
          [event.target.id]: event.target.value
        });
    }
    
    adminLogin(){
        axios.post('/users/admin',{username:this.state.username,password:this.state.password})
        .then((response) => {
            if( response.data.success ){
                this.props.history.push('/main-admin'); 
                //like == window.location = "/main-admin";
            }else{
              alert("Error!!");
            }
        })
        .catch(function(error){
            console.log(error);
            //Perform action based on error
        });
        
    }

    login(){
        axios.post('/users/login', {username:this.state.username,password:this.state.password})
        .then((response) => {
            if( this.state.username === "Administrator" && this.state.password === "123456"){
                //console.log(response);
                this.adminLogin();
            }
            if( response.data.success ){
                this.setState({user_id:response.data.data[0].id,username:response.data.data[0].username});
                this.props.history.push('/main');
            }else{
              alert("username or password invalid");
            }
        })
        .catch(function(error){
            console.log(error);
            //Perform action based on error
        });
    }

    checkSession(){
        axios.get('/users/checklogin')
        .then((response) => {
            //console.log(response);
            if( response.data){
                if(response.data.username === "Administrator"){
                    this.props.history.push('/main-admin');    
                }
                else{
                    this.props.history.push('/main');
                }
            }
            else{
                this.props.history.push('/');
            }
        })
        .catch(function(error){
            console.log(error);
            //Perform action based on error
        });
    }

  
}



export default Login;