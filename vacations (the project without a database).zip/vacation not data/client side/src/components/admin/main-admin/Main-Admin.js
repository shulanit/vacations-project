import React, { Component } from 'react';
import { Link } from "react-router-dom";
import './main-admin.css';
import axios from 'axios';
import Modal from 'react-awesome-modal';
import Chart from '../../charts/charts';

class MainAdmin extends Component {
    constructor(props) {
        super(props);
    }

    state = {
        vacations: [],
        show_error_message: false,
        error_message: "",
        edit_vacation_id: "",
        edit_vacation_destination: "",
        edit_vacation_description: "",
        edit_vacation_img: "",
        edit_vacation_start: "",
        edit_vacation_end: "",
        edit_vacation_price: 0,
        show_edit_modal: false
    }

    componentDidMount() {
        this.getVacationsToAdmin();
    }

    closeModal() {
        this.setState({
            show_edit_modal: false
        });
    }

    render() {
        return (
            <div>
                <Modal
                    visible={this.state.show_edit_modal}
                    width="400"
                    height="400"
                    effect="fadeInUp"
                // onClickAway={() => this.closeModal()}
                >
                    <div className="modal-edit-vacation">
                        <i className="fa fa-times" onClick={() => this.closeModal()}></i>
                        <h1>Edit Vacation</h1>
                        <h4>Change Vacation Data</h4>
                        <div className="edit-fields">
                            <div className="form-group">
                                <label>Destination</label>
                                <input className="form-control" id="edit_vacation_destination" onChange={this.handleChange} value={this.state.edit_vacation_destination} placeholder="Destination..." />
                            </div>
                            <div className="form-group">
                                <label>Description</label>
                                <input className="form-control" id="edit_vacation_description" onChange={this.handleChange} value={this.state.edit_vacation_description} placeholder="Description..." />
                            </div>
                            <div className="form-group">
                                <label>Image Url</label>
                                <input className="form-control" id="edit_vacation_img" onChange={this.handleChange} value={this.state.edit_vacation_img} placeholder="Image Url..." />
                            </div>
                            <div className="form-group">
                                <label>Date Start</label>
                                <input type="text" className="form-control" id="edit_vacation_start" onChange={this.handleChange} value={this.state.edit_vacation_start} placeholder="Date start..." />
                            </div>
                            <div className="form-group">
                                <label>Date End</label>
                                <input type="text" className="form-control" id="edit_vacation_end" onChange={this.handleChange} value={this.state.edit_vacation_end} placeholder="Date End..." />
                            </div>
                            <div className="form-group">
                                <label>Price</label>
                                <input className="form-control" id="edit_vacation_price" onChange={this.handleChange} value={this.state.edit_vacation_price} placeholder="Price..." />
                            </div>
                            <div className="btn btn-success" onClick={this.saveEditVacation.bind(this)} >Save</div>
                        </div>

                    </div>
                </Modal>

                <div className="container">
                    <h2 id="title-admin">hello administrator!</h2>
                    <div className="row">
                        <div className="col-md-12">
                            <button type="button" className="btn btn-danger" id="logout" onClick={this.logout.bind(this)}>Logout</button>
                            <div className="btn btn-danger" id="add"><Link to={'/add'} id="link-add">add vacation</Link></div>
                        </div>
                        <div className="main">
                            <h4>all vacations</h4>
                            <div className="row">
                                {
                                    this.state.vacations.map((vacation) =>
                                        <div className="col-md-4" key={vacation.id}>
                                            <div className="m-2">
                                                <div className="card cube">
                                                    <div className="icons">
                                                        <span className="vacation-id">ID: {vacation.id}</span>
                                                        <i className="fas fa-times" id="delete" onClick={this.deleteVacation.bind(this, vacation.id)}></i>
                                                        <i className="fas fa-pencil-alt" id="edit" onClick={this.openEditVacation.bind(this, vacation.id)}></i>
                                                        <div className="count_followers">f: {vacation.count_followers}</div>
                                                    </div>
                                                    <img className="card-img-top" src={vacation.image} alt="Card image cap" />
                                                    <div className="card-title">
                                                        {vacation.destination}
                                                    </div>
                                                    <div className="card-body">
                                                        <div className="card-text">{vacation.description}</div>
                                                        <div className="card-text">start: {vacation.dep}</div>
                                                        <div className="card-text">end: {vacation.endd}</div>
                                                    </div>
                                                    <div className="card-footer">
                                                        <div className="card-text">{vacation.price} $ </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    )
                                }
                            </div> {/*second row*/}
                        </div> {/*main*/}
                    </div> {/*first row*/}
                    <div className="row">
                        <div className="col-md-12">
                        this is charts
                        {this.state.vacations.length>0 ? 
                        <Chart data={this.state.vacations}/> : null}
                        </div> 
                    </div>
                </div>  {/*container*/}
            </div>
        )

    }

    handleChange = event => {
        this.setState({
            [event.target.id]: event.target.value
        });
    }

    logout() {
        axios.post('/users/logout')
            .then((response) => {
                this.props.history.push('/');
            })
    }

    getVacationsToAdmin() {
        axios.get('/vacations/all', {})
            .then((response) => {
                if (response.data.data) {
                    this.setState({ vacations: response.data.data });
                } else {
                    this.state.error_message = response.data.response_text;
                    this.state.show_error_message = true;
                    this.setState({});
                }
            })
            .catch(function (error) {
                console.log(error);
                //Perform action based on error
            });
    }

    deleteVacation(id) {
        console.log(id);
        axios.delete('/vacations/delete', { data: { id: id } })
            .then((response) => {
                if (response.data.success) {
                    this.getVacationsToAdmin();
                } else {
                    this.state.error_message = response.data.response_text;
                    this.state.show_error_message = true;
                    this.setState({});
                }
            })
            .catch(function (error) {
                console.log(error);
                this.state.error_message = error.response.statusText + ", " + error.response.data;
                this.state.show_error_message = true;
                this.setState({});
                //Perform action based on error
            });
    }

    openEditVacation(id) {
        axios.get('/vacations/vacationById', { params: { id: id } })
            .then((response) => {
                console.log(response);
                if (response.data.success == 1) {
                    let vacation_to_edit = response.data.data[0];
                    this.state.edit_vacation_id = vacation_to_edit.id;
                    this.state.edit_vacation_destination = vacation_to_edit.destination;
                    this.state.edit_vacation_description = vacation_to_edit.description;
                    this.state.edit_vacation_img = vacation_to_edit.image;
                    this.state.edit_vacation_start = vacation_to_edit.dep;
                    this.state.edit_vacation_end = vacation_to_edit.endd;
                    this.state.edit_vacation_price = vacation_to_edit.price;
                    this.state.show_edit_modal = true;
                    this.setState({});
                } else {
                    this.state.error_message = response.data.response_text;
                    this.state.show_error_message = true;
                    this.setState({});
                }
            })
            .catch(function (error) {
                console.log(error);
                this.state.error_message = error.response.statusText + ", " + error.response.data;
                this.state.show_error_message = true;
                this.setState({});
                //Perform action based on error
            });
    }

    saveEditVacation() {
        let vacation = {
            id: this.state.edit_vacation_id,
            destination: this.state.edit_vacation_destination,
            description: this.state.edit_vacation_description,
            img: this.state.edit_vacation_img,
            start: this.state.edit_vacation_start,
            end: this.state.edit_vacation_end,
            price: this.state.edit_vacation_price
        }
        
        console.log(vacation);
        axios.put('/vacations/update', { vacation: vacation })
            .then((response) => {
                console.log(response);
                this.closeModal();
                if (response.data.success) {
                    this.getVacationsToAdmin();
                } else {
                    this.state.error_message = response.data.response_text;
                    this.state.show_error_message = true;
                    this.setState({});
                }
            })
            .catch(function (error) {
                console.log(error);
                //Perform action based on error
            });
    }


}

export default MainAdmin;
