import React,{Component} from 'react';
import './add-vacation.css';
import axios from 'axios';

class AddVacation extends Component{
    state = {
        add_destination:"",
        add_description:"",
        add_img:"",
        add_start:"",
        add_end:"",
        add_price:0,  
        error_message:""
    }


    render(){
        return(
            <div className="container add_v">
                <div className = 'form'>
                    <h3>Add Vacation</h3>
                    <div className="row">
                        <div className="col-md-2"></div>
                        <div className="add-fields col-md-8">
                            <div className="form-group">
                                <label>Destination</label>
                                <input className="form-control" id="add_destination" onChange={this.handleChange} value={this.state.add_destination} placeholder="Destination..." />
                            </div>
                            <div className="form-group">
                                <label>Description</label>
                                <input className="form-control" id="add_description" onChange={this.handleChange} value={this.state.add_description} placeholder="Description..." />
                            </div>
                            <div className="form-group">
                                <label>Image Url</label>
                                <input className="form-control" id="add_img" onChange={this.handleChange} value={this.state.add_img} placeholder="Image Url..." />
                            </div>
                            <div className="form-group">
                                <label>Start Date</label>
                                <input type="date" className="form-control" id="add_start" onChange={this.handleChange} value={this.state.add_start} placeholder="Start Date...1990/12/30" />
                            </div>
                            <div className="form-group">
                                <label>End Date</label>
                                <input type="date" className="form-control" id="add_end" onChange={this.handleChange} value={this.state.add_end} placeholder="End Date..." />
                            </div>
                            <div className="form-group">
                                <label>Price</label>
                                <input className="form-control" id="add_price" onChange={this.handleChange} value={this.state.add_price} placeholder="Price..." />
                            </div>
                            <div className="btn btn-success" onClick={this.saveVacation.bind(this)}>Save</div>
                            
                            <div className="alert alert-danger" role="alert">
                                {this.state.error_message}
                            </div>
                        
                        </div>
                        <div className="col-md-2"></div>
                    </div>
                </div>
            </div>
            
        )
    }

    handleChange = event => {
        this.setState({
            [event.target.id]: event.target.value
        });
    }

    saveVacation(){
        let vacation = {
            id:this.state.id,
            destination:this.state.add_destination,
            description:this.state.add_description,
            img:this.state.add_img,
            start:this.state.add_start,
            end:this.state.add_end,
            price:this.state.add_price
        }
        axios.put('/vacations/add',{vacation:vacation})
        .then( (response) => {
            console.log(response);
            if( response.data.success == 1 ){
               console.log( "vacation created in success");
               //this.saveVacationToFollow(new_id);
                this.props.history.push('/main-admin');
              }else{
                this.state.error_message=response.data.response_text;
                this.state.show_error_message = true;
                this.setState({});
              }
          })
          .catch(function(error){
            console.log(error);
            //Perform action based on error
        });
       
    }

   
}

export default AddVacation;