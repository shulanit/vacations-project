var express = require('express');
var router = express.Router();
var con = require('../bin/DataBase/connection').getpool();
var response = require('../modules/response');

/* GET vacations page. */
router.get('/all', function(req, res, next) {
  //response.clearResponse();
  //var sql= "Select v.id,Count(f.user_id) as count_followers,v.description,v.destination,v.image, date_format(departing, '%d/%m/%Y') AS dep,date_format(end, '%d/%m/%Y') AS endd,v.price FROM vacations_table v JOIN followers f ON v.id=f.vacation_id GROUP BY f.vacation_id";
  //var sql = `SELECT *,date_format(departing,'%d/%m/%Y') as dep,date_format(end,'%d/%m/%Y') as endd FROM vacations_table`;
  var sql = "Select v.id,Count(f.user_id) as count_followers,v.description,v.destination,v.image, date_format(departing, '%d/%m/%Y') AS dep,date_format(end, '%d/%m/%Y') AS endd,v.price FROM vacations_table v LEFT JOIN followers f ON f.vacation_id=v.id GROUP BY v.id"
  //var sql2 = "SELECT `vacation_id`, count(`vacation_id`) as count_followers  FROM followers  GROUP BY vacation_id"; 


  con.query(sql,function(err,results,fields){ 
      console.log(results); 
      if( err ){
          response.err = 1;
          response.response_text = err.message;
          res.json(response);
      }
      response.success = 1;
      response.response_text = "success getting results";
      response.data = results;
      res.json(response);
  });

});


router.get('/', function(req, res, next) {
  response.clearResponse();
  var user_id = req.session.user_id; 
    var sql = `SELECT *,date_format(departing,'%d/%m/%Y') as dep,date_format(end,'%d/%m/%Y') as endd FROM vacations_table JOIN followers ON vacations_table.id=followers.vacation_id WHERE followers.user_id=${user_id}`;
      con.query(sql,function(err,results,fields){  
        if( err ){
            response.err = 1;
            response.response_text = err.message;
            res.json(response);
        }
        response.success = 1;
        response.response_text = "success getting results";
        response.data = results;
        res.json(response);
    });
});

router.get('/others', function(req, res, next) {
    var all_sql = `SELECT *,date_format(departing,'%d/%m/%Y') as dep,date_format(end,'%d/%m/%Y') as endd FROM vacations_table`;
    con.query(all_sql,function(err,results,fields){   
        if( err ){
            response.err = 1;
            response.response_text = err.message;
            res.json(response);
        }
        //console.log(results);
        response.success = 1;
        response.response_text = "success getting results";
        response.data = results;
        res.json(response);
    });
});


router.put('/add',function(req, res, next){
    console.log( req.body );
    var destination = req.body.vacation.destination;
    var description = req.body.vacation.description;
    var img = req.body.vacation.img;
    var start = req.body.vacation.start;
    var end = req.body.vacation.end;
    var price = req.body.vacation.price;

    con.query(`SELECT id,destination,departing,end FROM vacations_table 
    WHERE destination='${destination}' and departing='${start}' and end='${end}'`,function(err,results,fields){
      if( err ){
        response.err = 1;
        response.response_text = err.message;
        res.json(response);
        res.end();
    }
      console.log(results.id);
      if( results.length > 0 ){
        response.success = 0;
        response.response_text = "vacation found. Please select another vacation";
        res.json(response);
      }
    else{
        var sql = `INSERT INTO vacations_table (description,destination,image,departing,end,price) values ('${description}','${destination}','${img}','${start}','${end}','${price}')`;
        try{
            con.query(sql,function(err,results,fields){
              if( err ){
                  response.err = 1;
                  response.response_text = err.message;
                  response.data = results;
                  res.json(response);
                  res.end();
              }
              response.success = 1;
              response.response_text = " vacation created in success! ";
              response.data = results;
              res.json(response);
              res.end();
            });
           
          //}
          }catch(SqlErr){
            response.err = 1;
            response.response_text = SqlErr.message;
            res.json(response);
            res.end();
            console.log(SqlErr);
          }
        }
    })
})

router.delete('/delete',function(req,res,next){
    var id = req.body.id;
    console.log( req.body.id );
    if( id ){
      var sql1 = `DELETE FROM vacations_table WHERE id = ${id}`;
      var sql2 = `DELETE FROM followers WHERE vacation_id = ${id}`;
      console.log(sql1,sql2);
      try{
          con.query(sql1,function(err,results,fields){
              if( err ){
                  response.err = 1;
                  response.response_text = err.message;
                  res.json(response);
                  res.end();
              }
              response.success = 1;
              response.response_text = "success Deleting Record";
              response.data = results;
              //res.json(response);
              //res.end();
          });
          con.query(sql2,function(err,results,fields){
            if( err ){
                response.err = 1;
                response.response_text = err.message;
                res.json(response);
                res.end();
            }
            response.success = 1;
            response.response_text = "success Deleting Record";
            response.data = results;
            res.json(response);
            res.end();
        });
      }catch(err_catch){
          response.err = 1;
          response.response_text = err_catch.message;
          res.json(response);
          res.end();
      }
  }else{
      response.err = 1;
      response.response_text = "Id Not Found";
      res.json(response);
      res.end();
  }
  

});

router.get('/vacationById',function(req, res, next){
  var id = req.query.id;
  console.log("Edit ID: " + id);
  con.query(`SELECT *,date_format(departing,'%d/%m/%Y') as dep,date_format(end,'%d/%m/%Y') as endd FROM vacations_table where id=${id}`,function(err,results,fields){
      if( err ){
          response.err = 1;
          response.response_text = err.message;
          res.json(response);
          res.end();
      }
      console.log(response);
      response.success = 1;
      response.response_text = "success getting results";
      response.data = results;
      res.json(response);
      res.end();
  });
});


router.put('/update',function(req,res,next){
  response.clearResponse();
  var id = req.body.vacation.id;
  var destination = req.body.vacation.destination;
  var description = req.body.vacation.description;
  var img = req.body.vacation.img;
  var start = req.body.vacation.start;
  var end = req.body.vacation.end;
  var price = req.body.vacation.price;
  
  var sql = `UPDATE vacations_table SET departing = STR_TO_DATE('${start}','%d/%m/%Y'),end = STR_TO_DATE('${end}','%d/%m/%Y') Where id=${id}`;//this is working!!!
  var sql2 = `UPDATE vacations_table SET description='${description}',destination='${destination}',image='${img}',price='${price}' WHERE id=${id}`;
  
  try{
    con.query(sql,function(err,results,fields){
        if( err ){
            response.err = 1;
            response.response_text = err.message;
            res.json(response);
            res.end();
        }
        response.success = 1;
        response.response_text = "success Deleting Record";
        response.data = results;
        //res.json(response);
        //res.end();
    });
    con.query(sql2,function(err,results,fields){
      if( err ){
          response.err = 1;
          response.response_text = err.message;
          res.json(response);
          res.end();
      }
      response.success = 1;
      response.response_text = "success Deleting Record";
      response.data = results;
      res.json(response);
      res.end();
    });
  }catch(err_catch){
    response.err = 1;
    response.response_text = err_catch.message;
    res.json(response);
    res.end();
  }
  
});

// router.put('/update2',function(req,res,next){
//   var id = req.body.vacation.id;
//   var destination = req.body.vacation.destination;
//   var description = req.body.vacation.description;
//   var img = req.body.vacation.img;
//   var start = req.body.vacation.start;
//   var end = req.body.vacation.end;
//   var price = req.body.vacation.price;
  
// })


module.exports = router;
