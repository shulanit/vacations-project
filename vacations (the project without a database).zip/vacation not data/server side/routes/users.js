var express = require('express');
var router = express.Router();
var con = require('../bin/DataBase/connection').getpool();
var response = require('../modules/response');
//var createBrowserHistory = require('history').createBrowserHistory;

/* GET users listing. */

router.get('/checklogin', function (req, res, next) {
  console.log('checklogin')
  console.log(req.session)

  if (req.session.isconnected == true) {
    let user = {
      username:req.session.username,
      id:req.session.user_id,
      log:true
    }
    res.json(user);
  }
  else {
    res.send(false);
  }
});

router.post('/login',function(req,res,next){
  console.log( req.body );
  var username = req.body.username;
  var password = req.body.password;
  req.session.isconnected = false;
  //req.session.username

  //console.log(`SELECT id,name,lastname,username,password,role FROM USERS 
  //WHERE username='${username}' and password='${password}'`);
  con.query(`SELECT id,name,lastname,username,password,role FROM USERS 
  WHERE username='${username}' and password='${password}'`,function(err,results,fields){
    if( err ){
        response.err = 1;
        response.response_text = err.message;
        res.json(response);
        res.end();
    }
    console.log(results);
    if( results.length > 0 ){
      req.session.isconnected = true;
      req.session.username = req.body.username;
      req.session.user_id = results[0].id; // זה אמור לשמור את זה
      response.username = results[0].username;
      response.success = 1;
      response.response_text = "user Found";
      //console.log(req.session);

    }else{
      response.success = 0;
      response.response_text = "user not Found";
    }

    response.data = results;
    console.log(response.response_text);
    res.json(response);
    response.clearResponse();
    res.end();
  });
})

router.post('/admin',function(req,res,next){
  console.log( req.body );
  var username = req.body.username;
  var password = req.body.password;
  req.session.isAdmin = true;

  con.query(`SELECT name,lastname,username,password,role FROM USERS 
  WHERE username='${username}' and password='${password}'`,function(err,results,fields){
    if( err ){
      response.err = 1;
      response.response_text = err.message;
      res.json(response);
      res.end();
  }
  console.log(results.length);
  if( results.length > 0 ){
    req.session.isconnected = true;
    response.success = 1;
    response.response_text = "admin Found";
  }else{
    response.success = 0;
    response.response_text = "admin not Found";
  }

  response.data = results;
  console.log(response.response_text);
  res.json(response);
  res.end();
  })

});

router.put('/setlike',function(req,res,next){
  
  var user_id = req.session.user_id;
  var vacation_id = req.body.id;
  console.log(req.body,user_id);

     if (req.session.isconnected === true) {
       console.log("SELECT * FROM `followers` WHERE `vacation_id`=" + vacation_id + " and `user_id` =" + user_id)
      con.query("SELECT * FROM `followers` WHERE `vacation_id`=" + vacation_id + " and `user_id` =" + user_id, function (err, result, fields) {
        if (err) {
          console.log('query error' + err);
        } 
        else {
          if (result.length == 0) { // not following the vacation so making an INSERT
            con.query("INSERT INTO `followers`(`vacation_id`, `user_id`) VALUES (" + vacation_id + "," + user_id + ")", function (err, result, fields) {
              console.log(result);
              res.send('user id '+user_id+' is now fllowing vacation number '+vacation_id);
            })
          } else { 
            //console.log("DELETE FROM `followers` where `vacation_id`=" + vacation_id + " and `user_id`= " + user_id)
            con.query(`DELETE FROM followers where vacation_id=${vacation_id} AND user_id=${user_id}`,function (err, result, fields) {
              res.send('user id '+user_id+' is no longer fllowing vacation number '+vacation_id);
            })
            }
        }
      })
  
    } else {
      res.send('not connected')
    }
});
  

//})

router.post('/logout',function(req,res,next){
  req.session.destroy();
  res.end();
})

module.exports = router;
