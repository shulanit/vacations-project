var express = require('express');
var router = express.Router();
var con = require('../bin/DataBase/connection').getpool();
var response = require('../modules/response');


/* GET registration listing. */

router.put('/create',function(req,res,next){
    console.log( req.body );
   
    var name = req.body.user.name;
    var lastname = req.body.user.lastname;
    var username = req.body.user.username;
    var password = req.body.user.password;
    
    var check = `SELECT username FROM users WHERE username='${username}'`;
    con.query(check,function(err,results){
      console.log(results);
      if( err ){
        response.err = 1;
        response.response_text = err.message;
        res.json(response);
        res.end();
      }
      if( results.length > 0 ){
        response.err = 1;
        response.response_text = "Existing user on the system. Please choose a different username";        
        res.json(response);
        res.end();
      }
      else{
        var sql = `INSERT INTO users (name,lastname,username,password) values ('${name}','${lastname}','${username}','${password}')`;
        try{
          con.query(sql,function(err,results,fields){
            if( err ){
                response.err = 1;
                response.response_text = err.message;
                response.data = results;
                res.json(response);
                res.end();
            }
            response.success = 1;
            response.response_text = "user created in success!";
            response.data = results;
            res.json(response);
            res.end();
          });
        }catch(SqlErr){
          response.err = 1;
          response.response_text = SqlErr.message;
          res.json(response.data);
          res.end();
          console.log(SqlErr);
        }

      }
    })
  })

module.exports = router;
